<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Pages migrated from the original hash-router app live in src/pages and use src/lib/router.tsx, a thin shim over TanStack Router (navigate/useRoute); keep new navigation compatible with it — why: preserves the ported code unchanged.
- AI text generation runs through the server function in src/lib/ai.functions.ts — why: keeps the AI key server-side.
