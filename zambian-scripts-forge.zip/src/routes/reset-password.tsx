import { createFileRoute } from "@tanstack/react-router";
import { ResetPassword } from "@/pages/ResetPassword";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set a new password | Zalemba" },
      { name: "description", content: "Choose a new password for your Zalemba account." },
      { property: "og:title", content: "Set a new password | Zalemba" },
      { property: "og:description", content: "Choose a new password for your Zalemba account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResetPassword,
});
