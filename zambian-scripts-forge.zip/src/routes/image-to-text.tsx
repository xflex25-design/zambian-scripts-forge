import { createFileRoute } from "@tanstack/react-router";
import { ImageToText } from "@/pages/ImageToText";

export const Route = createFileRoute("/image-to-text")({
  head: () => ({
    meta: [
      { title: "Image to Text Converter — Free OCR Online | Zalemba" },
      { name: "description", content: "Upload an image or screenshot and extract its text instantly. Free image to text converter with OCR." },
      { property: "og:title", content: "Image to Text Converter — Free OCR Online | Zalemba" },
      { property: "og:description", content: "Upload an image or screenshot and extract its text instantly. Free image to text converter with OCR." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ImageToText,
});
