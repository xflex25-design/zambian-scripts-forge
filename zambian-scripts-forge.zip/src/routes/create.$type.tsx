import { createFileRoute } from "@tanstack/react-router";
import { Create } from "@/pages/Create";
import { getDocType } from "@/lib/documents";

export const Route = createFileRoute("/create/$type")({
  head: ({ params }) => {
    const t = getDocType(params.type);
    const title = t?.seo.title ?? "Create a document | Zalemba";
    const description = t?.seo.description ?? "Create professional documents with Zalemba.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: Create,
});
