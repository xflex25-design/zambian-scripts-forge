import { createFileRoute } from "@tanstack/react-router";
import { Login } from "@/pages/Login";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log in | Zalemba" },
      { name: "description", content: "Log in to Zalemba to save and manage your documents." },
      { property: "og:title", content: "Log in | Zalemba" },
      { property: "og:description", content: "Log in to Zalemba to save and manage your documents." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Login,
});
