import { createFileRoute } from "@tanstack/react-router";
import { Landing, LANDINGS } from "@/pages/Landing";

export const Route = createFileRoute("/landing/$slug")({
  head: ({ params }) => {
    const l = LANDINGS[params.slug];
    const title = l?.metaTitle ?? "Zalemba";
    const description = l?.metaDescription ?? "Create professional documents with Zalemba.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: Landing,
});
