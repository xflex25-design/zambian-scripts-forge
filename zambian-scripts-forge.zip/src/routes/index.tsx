import { createFileRoute } from "@tanstack/react-router";
import { Home } from "@/pages/Home";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Zalemba – AI Letter and Document Generator in Zambia" },
      { name: "description", content: "Create professional letters, CVs, student appeals and formal documents with Zalemba. Answer a few simple questions and generate your document online." },
      { property: "og:title", content: "Zalemba – AI Letter and Document Generator in Zambia" },
      { property: "og:description", content: "Create professional letters, CVs, student appeals and formal documents with Zalemba. Answer a few simple questions and generate your document online." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});
