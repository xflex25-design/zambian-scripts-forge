import { createFileRoute } from "@tanstack/react-router";
import { Login } from "@/pages/Login";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create an account | Zalemba" },
      { name: "description", content: "Sign up for Zalemba to save your letters, CVs and documents." },
      { property: "og:title", content: "Create an account | Zalemba" },
      { property: "og:description", content: "Sign up for Zalemba to save your letters, CVs and documents." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Login,
});
