import { createFileRoute } from "@tanstack/react-router";
import { Account } from "@/pages/Account";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "My documents | Zalemba" },
      { name: "description", content: "View, edit and download your saved Zalemba documents." },
      { property: "og:title", content: "My documents | Zalemba" },
      { property: "og:description", content: "View, edit and download your saved Zalemba documents." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Account,
});
