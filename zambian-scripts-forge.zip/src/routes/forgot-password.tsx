import { createFileRoute } from "@tanstack/react-router";
import { Login } from "@/pages/Login";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Forgot password | Zalemba" },
      { name: "description", content: "Reset your Zalemba account password." },
      { property: "og:title", content: "Forgot password | Zalemba" },
      { property: "og:description", content: "Reset your Zalemba account password." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Login,
});
