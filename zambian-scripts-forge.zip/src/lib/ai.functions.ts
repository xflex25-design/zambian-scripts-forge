import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const generateText = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z
      .object({
        system: z.string().max(20000).optional(),
        prompt: z.string().min(1).max(40000),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI is not configured");
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3.8-flash",
        messages: [
          {
            role: "system",
            content:
              data.system ||
              "You are a professional assistant for document generation in Zambia.",
          },
          { role: "user", content: data.prompt },
        ],
        response_format: { type: "json_object" },
        temperature: 0.4,
        max_tokens: 8192,
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error(`AI gateway error [${res.status}]: ${body}`);
      if (res.status === 429) throw new Error("Too many requests, please try again shortly.");
      if (res.status === 402) throw new Error("AI credits exhausted.");
      throw new Error(`AI request failed [${res.status}]`);
    }
    const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
    return { text: json.choices?.[0]?.message?.content?.trim() ?? "" };
  });
