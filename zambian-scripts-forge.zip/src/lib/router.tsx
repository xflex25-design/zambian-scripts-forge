// Compatibility layer so the original pages keep their navigate()/useRoute() API
// while routing is handled by TanStack Router.
import { useLocation, useRouter, type AnyRouter } from "@tanstack/react-router";
import { useEffect, useMemo } from "react";

export type RouteInfo = {
  path: string;
  params: Record<string, string>;
  search: URLSearchParams;
};

let routerRef: AnyRouter | null = null;

export function RouterBridge() {
  const router = useRouter();
  useEffect(() => {
    routerRef = router;
  }, [router]);
  return null;
}

export function navigate(to: string) {
  const clean = to.startsWith("#") ? to.slice(1) : to;
  const href = clean.startsWith("/") ? clean : "/" + clean;
  if (routerRef) {
    void routerRef.navigate({ href });
  } else if (typeof window !== "undefined") {
    window.location.href = href;
  }
}

export function useRoute(): RouteInfo {
  const location = useLocation();
  const searchStr = location.searchStr;
  return useMemo(
    () => ({
      path: location.pathname.replace(/\/+$/, "") || "/",
      params: {},
      search: new URLSearchParams(searchStr),
    }),
    [location.pathname, searchStr],
  );
}

export function matchRoute(pattern: string, path: string): Record<string, string> | null {
  const patternParts = pattern.split("/").filter(Boolean);
  const pathParts = path.split("/").filter(Boolean);
  if (patternParts.length !== pathParts.length) return null;
  const params: Record<string, string> = {};
  for (let i = 0; i < patternParts.length; i++) {
    if (patternParts[i].startsWith("$")) {
      params[patternParts[i].slice(1)] = decodeURIComponent(pathParts[i]);
    } else if (patternParts[i] !== pathParts[i]) {
      return null;
    }
  }
  return params;
}
