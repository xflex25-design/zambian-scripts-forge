// Compatibility layer: the app now uses Lovable Cloud's generated client.
export { supabase } from "@/integrations/supabase/client";

export const isSupabaseConfigured = true;

export function getSupabaseConfig() {
  return { url: "", key: "", isConfigured: true };
}

export function isSecretApiKey(_key: string): boolean {
  return false;
}
