create table public.saved_documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  title text not null,
  content text not null,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.saved_documents to authenticated;
grant all on public.saved_documents to service_role;
alter table public.saved_documents enable row level security;
create index saved_documents_user_idx on public.saved_documents(user_id, created_at desc);
create policy "own select" on public.saved_documents for select to authenticated using (auth.uid() = user_id);
create policy "own insert" on public.saved_documents for insert to authenticated with check (auth.uid() = user_id);
create policy "own update" on public.saved_documents for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own delete" on public.saved_documents for delete to authenticated using (auth.uid() = user_id);